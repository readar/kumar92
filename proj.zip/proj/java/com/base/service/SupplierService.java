package com.base.service;

public class SupplierService {

}
