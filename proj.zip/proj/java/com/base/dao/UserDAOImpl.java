package com.base.dao;

public class UserDAOImpl {

}
